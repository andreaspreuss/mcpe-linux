echo "This script will set up and install Minecraft: Bedrock Edition on your debian-based Linux distro! [Ver 2.0 'Koala']"
echo Written by SupDroid Studio.
echo
sleep 1
echo Make sure you run this script as root [sudo]! If you did not, please hit CTRL+C now to cancel. Setup will proceed in 5 seconds...
sleep 5
cd ~
echo
echo Install core dependencies:
echo
dpkg --add-architecture i386
apt-get update
apt-get install git cmake pkg-config libssl-dev libcurl4-openssl-dev qtbase5-dev qtwebengine5-dev g++-multilib libpng-dev:i386 libx11-dev:i386 libxi-dev:i386 libcurl4-openssl-dev:i386 libudev-dev:i386 libevdev-dev:i386 libegl1-mesa-dev:i386 libasound2:i386 libssl-dev libcurl4-openssl-dev libuv1-dev libzip-dev libprotobuf-dev protobuf-compiler qtbase5-dev qtwebengine5-dev qtdeclarative5-dev libqt5svg5-dev qml-module-qtquick2 qml-module-qtquick-layouts qml-module-qtquick-controls qml-module-qtquick-controls2 qml-module-qtquick-window2 qml-module-qtquick-dialogs qml-module-qt-labs-settings qml-module-qt-labs-folderlistmodel libpulse0 libpulse0:i386 -y
echo
echo If you got any errors in this step [such as package not found errors], this means your distro [or version] is not supported.
echo "If the error was simply a network down error, please run 'sudo apt --fix-missing --fix-broken install', and then re-run this script."
echo If this is the case, please hit CTRL+C now to cancel setup.
echo If everything went well, the setup will proceed in 5 seconds...
sleep 5
echo
echo Install the MSA client [for Xbox Live support]:
echo
git clone --recursive https://github.com/minecraft-linux/msa-manifest.git msa
cd msa
mkdir -p build
cd build
cmake -DENABLE_MSA_QT_UI=ON ..
make -j12
make install
cd ~
echo
echo Install the Game Launcher:
echo
git clone --recursive https://github.com/minecraft-linux/mcpelauncher-manifest.git mcpelauncher
cd mcpelauncher
mkdir -p build
cd build
cmake ..
make -j12
make install
cd ~
echo
echo Install the Qt UI:
echo
git clone --recursive https://github.com/minecraft-linux/mcpelauncher-ui-manifest.git mcpelauncher-ui
cd mcpelauncher-ui
mkdir -p build
cd build
cmake ..
make -j12
make install
cd ~
echo
echo Removing the installation files to free up some space...
rm -rf msa
rm -rf mcpelauncher
rm -rf mcpelauncher-ui
sleep 0.5
echo
echo If everything went well, Minecraft: Bedrock Edition should now be installed on your system.
echo You should find Minecraft: Bedrock Edition launcher or something similar in your apps list.
echo From here you will need to sign in with your Google Account to verify that you own Minecraft from Google Play.
echo If you do not own Minecraft on Google Play, please go to http://bit.ly/mcpe-linux-zip to be able to download Minecraft.
echo If you need any help or support, please contact us at supdroid@mail.uk, or visit us online at http://bit.ly/supdroid.
sleep 1
echo
echo To uninstall Minecraft, simply run the uninstall script as root [sudo].
