#!/bin/bash
echo "The data of Minecraft: Bedrock Edition will be removed from your system."
echo "Please make sure that you DID NOT run this script as root [sudo]. If you did, you'll need to re-run it again normally afterwards!"
sleep 3
echo
cd ~/.local/share
echo "Removing data..."
rm -rf msa
rm -rf msa-ui-qt
rm -rf mcpelauncher
rm -rf "Minecraft Linux Launcher"
sleep 1
echo
echo "Data of Minecraft: Bedrock Edition has now been completely removed from your system."
cd ~
