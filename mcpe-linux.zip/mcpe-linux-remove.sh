echo This script will remove Minecraft: Bedrock Edition from its installed locations on your system.
echo It will also remove the folders created in your home directory.
echo This script only works if run as root [sudo].
sleep 1
echo
echo Removing components from installed locations:
sleep 1
echo
echo Removing msa-daemon...
rm -rf /usr/local/bin/msa-daemon
sleep 0.5
echo Removing msa-ui-qt...
rm -rf /usr/local/bin/msa-ui-qt
sleep 0.5
echo Removing msa-ui-gtk
rm -rf /usr/local/bin/msa-ui-gtk
sleep 0.5
echo Removing mcpelauncher-client...
rm -rf /usr/local/bin/mcpelauncher-client
sleep 0.5
echo Removing mcpelauncher...
rm -rf /usr/local/share/mcpelauncher
sleep 0.5
echo Removing mcpelauncher-ui-qt...
rm -rf /usr/local/bin/mcpelauncher-ui-qt
sleep 0.5
echo Removing mcpelauncher from the application list...
rm -rf /usr/local/share/applications/mcpelauncher-ui-qt.desktop
sleep 0.5
echo Removing the icon of mcpelauncher...
rm -rf /usr/local/share/pixmaps/mcpelauncher-ui-qt.png
echo
echo Removing folders created in ~:
sleep 1
cd ~
echo
echo Removing msa...
rm -rf msa
sleep 0.5
echo Removing mcpelauncher...
rm -rf mcpelauncher
sleep 0.5
echo Removing mcpelauncher-ui...
rm -rf mcpelauncher-ui
sleep 0.5
echo Removing data from ~/.local/share...
rm -rf .local/share/mcpelauncher
rm -rf .local/share/'Minecraft Linux Launcher'
rm -rf .local/share/msa
rm -rf .local/share/msa-ui-qt
sleep 0.5
echo
echo Minecraft: Bedrock Edition has now been completely removed from your system,
echo however, if you did not run as root [sudo], the installed directories in /usr/local will still remain!
