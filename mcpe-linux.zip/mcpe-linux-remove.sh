#!/bin/bash
echo "Minecraft: Bedrock Edition will be removed from your system."
echo "This script only works if run as root [sudo]."
sleep 1
echo
echo "Removing components from installed locations:"
sleep 1
echo
echo "Removing msa-daemon..."
rm -rf /usr/bin/msa-daemon
rm -rf /usr/local/bin/msa-daemon
sleep 0.5
echo "Removing msa-ui-qt..."
rm -rf /usr/bin/msa-ui-qt
rm -rf /usr/local/bin/msa-ui-qt
sleep 0.5
echo "Removing msa-ui-gtk..."
rm -rf /usr/bin/msa-ui-gtk
rm -rf /usr/local/bin/msa-ui-gtk
sleep 0.5
echo "Removing mcpelauncher-client..."
rm -rf /usr/bin/mcpelauncher-client
rm -rf /usr/local/bin/mcpelauncher-client
sleep 0.5
echo "Removing mcpelauncher..."
rm -rf /usr/share/mcpelauncher
rm -rf /usr/local/share/mcpelauncher
sleep 0.5
echo "Removing mcpelauncher-ui-qt..."
rm -rf /usr/bin/mcpelauncher-ui-qt
rm -rf /usr/local/bin/mcpelauncher-ui-qt
sleep 0.5
echo "Removing mcpelauncher from the application list..."
rm -rf /usr/share/applications/mcpelauncher-ui-qt.desktop
rm -rf /usr/local/share/applications/mcpelauncher-ui-qt.desktop
sleep 0.5
echo "Removing the icon of mcpelauncher..."
rm -rf /usr/share/pixmaps/mcpelauncher-ui-qt.png
rm -rf /usr/local/share/pixmaps/mcpelauncher-ui-qt.png
echo
sleep 1
echo "Minecraft: Bedrock Edition has now been completely removed from your system."
echo "Please run 'mcpe-linux-remove-data.sh' WITHOUT administrator permissions if you would like to remove the data from .local/share [not necessary if reinstalling]."
