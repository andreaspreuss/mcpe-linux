echo This script will remove Minecraft: Bedrock Edition from its installed locations on your system.
echo However, it will not remove the folders created in your home directory.
echo This script only works if run as root [sudo].
sleep 1
echo
echo Removing msa-daemon...
rm /usr/local/bin/msa-daemon
sleep 0.5
echo Removing msa-ui-qt...
rm /usr/local/bin/msa-ui-qt
sleep 0.5
echo Removing msa-ui-gtk
rm /usr/local/bin/msa-ui-gtk
sleep 0.5
echo Removing mcpelauncher-client...
rm /usr/local/bin/mcpelauncher-client
sleep 0.5
echp Removing mcpelauncher...
rm -r /usr/local/share/mcpelauncher
sleep 0.5
echo Removing mcpelauncher-ui-qt...
rm /usr/local/bin/mcpelauncher-ui-qt
sleep 0.5
echo Removing mcpelauncher from the application list...
rm /usr/local/share/applications/mcpelauncher-ui-qt.desktop
sleep 0.5
echo Removing the icon of mcpelauncher...
rm /usr/local/share/pixmaps/mcpelauncher-ui-qt.png
echo 
echo Minecraft: Bedrock Edition should now be removed from your system.
echo Do not worry if any errors occured, as some components simply could not have been installed in the first place.
