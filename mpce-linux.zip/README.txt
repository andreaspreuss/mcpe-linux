This ZIP file contains 2 scripts; one to install Minecraft: Bedrock Edition and the other to remove Minecraft: Bedrock Edition.
Scripts written by SupDroid Studio.

Make sure you extract both scripts to your home directory, and NOT in any subdirectories. If it is in a subdirectory such as Downloads, please move them to the home directory.

Now open a terminal tab and run the following:

TO INSTALL: sudo bash mcpe-linux-setup.sh
TO REMOVE: sudo bash mcpe-linux-remove.sh

It is vital you include the "sudo" value to ensure you are running the script as root. If you don't, some parts of the script will fail and MCPE will be half-installed. Not very helpful!

The removal script only removes the modules that are installed to the /usr/local directory. It WILL NOT remove the folders created in your home directory; you'll need to remove them yourself.
If you don't remove the folders created in your home directory and you run the install script again, it will most likely fail.
Please note that to delete the folders created in the /home directory you might need to run the file manager as root. On Ubuntu, this can be done with "sudo nautilus".

That's pretty much it! If you need help at any stage, don't hesistate to contact us at supdroid@mail.uk.

So, what are you waiting for? Close this file and begin!
